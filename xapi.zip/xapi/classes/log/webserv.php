<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External xapi log store plugin
 *
 * @package    logstore_xapi
 * @copyright  2015 Jerrett Fowler <jfowler@charitylearning.org>
 *                  Ryan Smith <ryan.smith@ht2.co.uk>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */



namespace logstore_xapi\log;


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);





/*parse_str($_SERVER['QUERY_STRING']);*/


require_once(__DIR__ . '/../../vendor/autoload.php');

use \XREmitter\Controller as xapi_controller;
use \XREmitter\Repository as xapi_repository;
use \XREmitter\Filer as xapi_filer;
use \TinCan\RemoteLRS as tincan_remote_lrs;
use \MXTranslator\Controller as translator_controller;
use \LogExpander\Controller as moodle_controller;
use \LogExpander\Repository as moodle_repository;
use \TinCan\RemoteLRS as TinCanRemoteLrs;
use \TinCan\Statement as TinCanStatement;




use \stdClass as php_obj;


/**
 * This class processes events and enables them to be sent to a logstore.
 *
 */



$p = new process();


$e = new fakeEvent();

$e->userid = $_POST["userid"];
$e->username = $_POST["username"];
$e->lang = $_POST["lang"];
$e->homepage = $_POST["homepage"];
$e->info = $_POST["info"];
$e->timestamp = $_POST["timestamp"];
$e->appname = $_POST["appname"];
$e->appsummary = $_POST["appsummary"];

$e->sessionid = $_POST["sessionid"];

$e->event = $_POST["event"];

$e->ip = $_POST["ip"];

$e->type =  $_POST["type"];
$e->appurl =  $_POST["appurl"];


$e->course_url = $_POST["course_url"];
$e->course_shortname = $_POST["course_shortname"];
$e->course_fullname = $_POST["course_fullname"];
$e->course_summary = $_POST["course_summary"];
$e->course_type = $_POST["course_type"];
$e->course_module = $_POST["course_module"];
$e->courseid = $_POST["courseid"];

//module

$e->mod_url= $_POST["mod_url"];
$e->mod_name = $_POST["mod_name"];
$e->mod_intro = $_POST["mod_intro"];
$e->mod_type = $_POST["mod_type"];




$opts = $e->createOpts(1);

$events = array($opts);

$p->process_events($events);


class fakeEvent {

	public $event = "";

public function createOpts($create_mode) {

	$opts = array();


	$opts['time']=$this->timestamp;



	$opts['event']['eventname'] = $this->event;
	$opts['event']['timecreated'] = $this->timestamp;
	$opts['event']['courseid'] =  $this->courseid;
  $opts['sessionid'] =  $this->sessionid;

  $opts['event']['ip'] =$this->ip;


	$opts['user']= new php_obj();
	$opts['user']->id = $this->userid;
  $opts['user']->url = $this->homepage;
	$opts['user']->username = $this->username;

	$opts['info'] = $this->info;

    $opts['app']= new php_obj();
    $opts['app']->url = $this->appurl;
    $opts['app']->fullname = $this->appname;
    $opts['app']->summary = $this->appsummary;
  	$opts['app']->type = $this->type;


  	$opts['course']= new php_obj();
	$opts['course']->lang = $this->lang;
	$opts['course']->url = $this->course_url;
	$opts['course']->fullname = $this->course_fullname;
	$opts['course']->summary = $this->course_summary;
	$opts['course']->type = $this->course_type;
	$opts['course']->module = $this->course_module;
    $opts['course']->shortname = $this->course_shortname;


	$opts['module']= new php_obj();
	$opts['module']->url = $this->mod_url;
    $opts['module']->name = $this->mod_name;
    $opts['module']->intro = $this->mod_intro;
   	$opts['module']->type = $this->mod_type;
    $opts['module']->shortname = $this->mod_name;



   	$opts['context_ext']= new php_obj();
	$opts['context_ext']->courseid = $this->courseid;

    return $opts;

}

}

class process extends php_obj {

       public function getGUID(){

    return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));


    }

      public function process_events(array $events) {

        // Initializes required services.
        $xapicontroller = new xapi_controller($this->connect_xapi_repository());
      //  $moodlecontroller = new moodle_controller($this->connect_moodle_repository());
        $translatorcontroller = new translator_controller();

        $translatorevents = $translatorcontroller->createEvents($events);
        $this->error_log_value('translatorevents', $translatorevents);



        if (empty($translatorevents)) {

         echo ("Debug: no events found");
            return;
        }

        $xapievents = $xapicontroller->createEvents($translatorevents);

      }

    private function error_log_value($key, $value) {
        $this->error_log('['.$key.'] '.json_encode($value));
    }

    private function error_log($message) {
        error_log($message."\r\n", 3, __DIR__.'/error_log.txt');
    }

  /**
     * Creates a connection the xAPI store.
     * @return xapi_repository
     */





    private function connect_xapi_repository() {

				$path = $_GET["path"];

				if ($path == "")
				{  return new xapi_repository(new tincan_remote_lrs(
	            'https://jisc.learninglocker.net/data/xAPI/',
	            '1.0.1',
	            '7258fc68e1dfa9880836bc6f316baa1bc3b7eba0',
	            '31538acb11216e537f74366f79963c8e3ade72f7'
	        ));}
					else{
						return new xapi_filer();
					}

    }


}
